package com.example.appcorrecto2;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.content.Intent;
import android.media.MediaPlayer;
import android.view.View;
import android.net.Uri;
import android.widget.Button;
import android.widget.Toast;



public class MainActivity extends AppCompatActivity {


    Button play1, play2, play3, play4, play5, play6, dowlon1, dowlon2, dowlon3, dowlon4, dowlon5,dowlon6,
           share1, share2, share3, share4, share5, share6, blu1, blu2, blu3, blu4, blu5, blu6;

    MediaPlayer mp1, mp2, mp3, mp4, mp5, mp6;

    String url1, url2, url3, url4, url5, url6;

   @Override
        protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        play1= (Button) findViewById(R.id.play1);
        play2= (Button) findViewById(R.id.play2);
        play3= (Button) findViewById(R.id.play3);
        play4= (Button) findViewById(R.id.play4);
        play5= (Button) findViewById(R.id.play5);
        play6= (Button) findViewById(R.id.play6);


        dowlon1= (Button)  findViewById(R.id.dowlon1);
        dowlon2= (Button)  findViewById(R.id.dowlon2);
        dowlon3= (Button)  findViewById(R.id.dowlon3);
        dowlon4= (Button)  findViewById(R.id.dowlon4);
        dowlon5= (Button)  findViewById(R.id.dowlon5);
        dowlon6= (Button)  findViewById(R.id.dowlon6);


        share1=(Button) findViewById(R.id.dowlon1);
        share2=(Button) findViewById(R.id.dowlon2);
        share3=(Button) findViewById(R.id.dowlon3);
        share4=(Button) findViewById(R.id.dowlon4);
        share5=(Button) findViewById(R.id.dowlon5);
        share6=(Button) findViewById(R.id.dowlon6);

        blu1=(Button) findViewById(R.id.blu1);
        blu2=(Button) findViewById(R.id.blu2);
        blu3=(Button) findViewById(R.id.blu3);
        blu4=(Button) findViewById(R.id.blu4);
        blu5=(Button) findViewById(R.id.blu5);
        blu6=(Button) findViewById(R.id.blu6);

        mp1= MediaPlayer.create(this,R.raw.play1);
        mp2= MediaPlayer.create(this,R.raw.play2);
        mp3= MediaPlayer.create(this,R.raw.play3);
        mp4= MediaPlayer.create(this,R.raw.play4);
        mp5= MediaPlayer.create(this,R.raw.play5);

        url1= "http://www.sonidosmp3gratis.com/download.php?id=5496&sonido=perro%201";
        url2="http://www.sonidosmp3gratis.com/download.php?id=16534&sonido=super%20mario%20bros";
        url3= "http://www.sonidosmp3gratis.com/download.php?id=16231&sonido=trabar%20carro%20alarma";
        url4= "http://www.sonidosmp3gratis.com/download.php?id=16792&sonido=pato%20donald%20tienes%20un%20mensaje";
        url5="http://www.sonidosmp3gratis.com/download.php?id=15283&sonido=mario%20bros%20vida";



        play1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mp1.isPlaying()){
                    mp1.pause();
                    Toast.makeText(MainActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
                }else{
                    mp1.start();
                    Toast.makeText(MainActivity.this,"Play", Toast.LENGTH_SHORT).show();
                }
            }
        });
        play2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mp2.isPlaying()){
                    mp2.pause();
                    Toast.makeText(MainActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
                }else{
                    mp2.start();
                    Toast.makeText(MainActivity.this,"Play", Toast.LENGTH_SHORT).show();
                }
            }
        });
        play3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mp3.isPlaying()){
                    mp3.pause();
                    Toast.makeText(MainActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
                }else{
                    mp3.start();
                    Toast.makeText(MainActivity.this,"Play", Toast.LENGTH_SHORT).show();
                }
            }
        });
        play4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mp4.isPlaying()){
                    mp4.pause();
                    Toast.makeText(MainActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
                }else{
                    mp4.start();
                    Toast.makeText(MainActivity.this,"Play", Toast.LENGTH_SHORT).show();
                }
            }
        });
        play5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mp5.isPlaying()){
                    mp5.pause();
                    Toast.makeText(MainActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
                }else{
                    mp5.start();
                    Toast.makeText(MainActivity.this,"Play", Toast.LENGTH_SHORT).show();
                }
            }
        });


        dowlon1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse(url1);
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });
        dowlon2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse(url2);
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });
        dowlon3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse(url3);
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });
        dowlon4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse(url4);
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });
        dowlon5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse(url5);
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });


        share1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, ShareActivity.class);
                startActivity(i);
            }
        });

        share2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, ShareActivity.class);
                startActivity(i);
            }
        });
        share3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, ShareActivity.class);
                startActivity(i);
            }
        });
        share4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, ShareActivity.class);
                startActivity(i);
            }
        });
        share5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, ShareActivity.class);
                startActivity(i);
            }
        });
        share6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, ShareActivity.class);
                startActivity(i);
            }
        });

        blu1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder alerta =new AlertDialog.Builder(MainActivity.this);
                alerta.setMessage("Muchas Felicidades, has conseguido un punto, sigue juntando puntos para recibir sorpresas....¿Deseas salir de la aplicacion")
                        .setCancelable(false)
                        .setPositiveButton("si", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int  which) {
                                finish();

                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int which) {
                                dialogInterface.cancel();
                            }
                        });
                AlertDialog titulo = alerta.create();
                titulo.setTitle("Felicidades!!!!!");
                titulo.show();


            }
        });

        blu2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder alerta =new AlertDialog.Builder(MainActivity.this);
                alerta.setMessage("Muchas Felicidades, has conseguido un punto, sigue juntando puntos para recibir sorpresas....¿Deseas salir de la aplicacion")
                        .setCancelable(false)
                        .setPositiveButton("si", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int  which) {
                                finish();

                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int which) {
                                dialogInterface.cancel();
                            }
                        });
                AlertDialog titulo = alerta.create();
                titulo.setTitle("Felicidades!!!!!");
                titulo.show();


            }
        });

       blu3.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               AlertDialog.Builder alerta =new AlertDialog.Builder(MainActivity.this);
               alerta.setMessage("Muchas Felicidades, has conseguido un punto, sigue juntando puntos para recibir sorpresas....¿Deseas salir de la aplicacion")
                       .setCancelable(false)
                       .setPositiveButton("si", new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialogInterface, int  which) {
                               finish();

                           }
                       })
                       .setNegativeButton("No", new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialogInterface, int which) {
                               dialogInterface.cancel();
                           }
                       });
               AlertDialog titulo = alerta.create();
               titulo.setTitle("Felicidades!!!!!");
               titulo.show();


           }
       });
       blu4.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               AlertDialog.Builder alerta =new AlertDialog.Builder(MainActivity.this);
               alerta.setMessage("Muchas Felicidades, has conseguido un punto, sigue juntando puntos para recibir sorpresas....¿Deseas salir de la aplicacion")
                       .setCancelable(false)
                       .setPositiveButton("si", new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialogInterface, int  which) {
                               finish();

                           }
                       })
                       .setNegativeButton("No", new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialogInterface, int which) {
                               dialogInterface.cancel();
                           }
                       });
               AlertDialog titulo = alerta.create();
               titulo.setTitle("Felicidades!!!!!");
               titulo.show();


           }
       });
       blu5.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               AlertDialog.Builder alerta =new AlertDialog.Builder(MainActivity.this);
               alerta.setMessage("Muchas Felicidades, has conseguido un punto, sigue juntando puntos para recibir sorpresas....¿Deseas salir de la aplicacion")
                       .setCancelable(false)
                       .setPositiveButton("si", new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialogInterface, int  which) {
                               finish();

                           }
                       })
                       .setNegativeButton("No", new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialogInterface, int which) {
                               dialogInterface.cancel();
                           }
                       });
               AlertDialog titulo = alerta.create();
               titulo.setTitle("Felicidades!!!!!");
               titulo.show();


           }
       });
       blu6.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               AlertDialog.Builder alerta =new AlertDialog.Builder(MainActivity.this);
               alerta.setMessage("Muchas Felicidades, has conseguido un punto, sigue juntando puntos para recibir sorpresas....¿Deseas salir de la aplicacion")
                       .setCancelable(false)
                       .setPositiveButton("si", new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialogInterface, int  which) {
                               finish();

                           }
                       })
                       .setNegativeButton("No", new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialogInterface, int which) {
                               dialogInterface.cancel();
                           }
                       });
               AlertDialog titulo = alerta.create();
               titulo.setTitle("Felicidades!!!!!");
               titulo.show();


           }
       });








   }


    }

